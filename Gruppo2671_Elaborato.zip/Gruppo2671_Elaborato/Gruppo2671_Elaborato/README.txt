PROGETTO DI DATABASE
GRUPPO 2671
BUZI SAJMIR
------------------------------------------------------------------------------------------------

ISTRUZIONI:

1) Spostarsi da terminale in questa cartella. Assicurarsi di avere MySQL installato (Altrimenti eseguire "brew install mysql").

2) Aprire in Visual Studio Code la cartella del progetto e controllare nel file databaseConnection se il DB è stato correttamente caricato.

3) Runnare dal .java principale "WelcomeFrame.java"

Per accedere come utente è possibile registrarsi come nuovo utente, oppure è possibile utilizzare il seguente account di prova, già impostato per mostrare le principali funzionalità:

Email = sajmirbuzi2001@gmail.com
Password = sam

Per accedere come utente usare le seguenti credenziali

email = adminCinema
password = a